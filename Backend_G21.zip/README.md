# REPOSITORIO DE BACKEND PARA EL GRUPO G21

Este sera el reposito del modulo de Backend para el grupo G21 de CodiGo. Las semanas estarán distribuidas en ramas, es decir, la semana 01 sera la rama <a href="https://www.google.com">semana 01</a>

1. Semana 01 <a href="https://www.google.com">click aqui</a>
2. Semana 02 <a href="https://www.google.com">click aqui</a>
3. Semana 03 <a href="https://www.google.com">click aqui</a>
4. Semana 04 <a href="https://www.google.com">click aqui</a>
5. Semana 05 <a href="https://www.google.com">click aqui</a>
6. Semana 06 <a href="https://www.google.com">click aqui</a>
7. Semana 07 <a href="https://www.google.com">click aqui</a>
8. Semana 08 <a href="https://www.google.com">click aqui</a>
9. Semana 09 <a href="https://www.google.com">click aqui</a>
10. Semana 10 <a href="https://www.google.com">click aqui</a>
